# frozen_string_literal: true

require_relative 'correcter'

p Correcter.correct(gets)
